﻿using System;
using System.Collections.Generic;
using Xunit;

namespace APM.SL.Test
{
  public class DiscountTest
  {
    //
    // FindDiscount
    //

  }
}
