﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APM.MVC.Models
{
  public class ProductListViewModel
  {
    public List<ProductViewModel> products { get; set; }

  }
}
